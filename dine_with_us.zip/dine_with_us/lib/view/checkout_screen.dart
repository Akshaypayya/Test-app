import 'package:dine_with_us/view/home_screeen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controller/product_controller.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({Key? key}) : super(key: key);

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  final AddProducts c = Get.put(AddProducts());
  int quantity = 0;
  int quantityy = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Order Summary",
          style: TextStyle(color: Colors.grey),
        ),
        iconTheme: IconThemeData(color: Colors.grey.shade500, size: 38),
        backgroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Column(
            children: [
              Card(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8.0),
                  child: Container(
                    decoration: const BoxDecoration(color: Colors.white),
                    child: Column(
                      children: [
                        Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(top: 10.0),
                              child: ClipRRect(
                                  borderRadius: BorderRadius.circular(8.0),
                                  child: Container(
                                    height: 70,
                                    width: 360,
                                    decoration: BoxDecoration(
                                      color: Colors.green.shade900,
                                    ),
                                    child:  Center(
                                      child: Obx(() => Text(
                                        "${c.total} Dishes - ${c.total} Items",
                                        style: TextStyle(
                                            color: Colors.white, fontSize: 22),
                                        textAlign: TextAlign.center,
                                      ),
                                      ),
                                    ),
                                  )),
                            ),



                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 30),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 5.0),
                                  child: Row(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    children: [
                                      Image.asset('assets/images/veg.png',
                                          height: 28, width: 28),
                                      const SizedBox(width: 5),
                                      const Text("Gobi\nManchurian\nDry",
                                          style: TextStyle(
                                              fontSize: 18,
                                              fontWeight: FontWeight.bold)),
                                      Card(
                                          shape: const StadiumBorder(),
                                          color: Colors.green.shade900,
                                          child: SizedBox(
                                            // height: 50,
                                            // width: 159,
                                              child: Row(
                                                children: [
                                                  IconButton(
                                                    icon: const Icon(Icons.remove,
                                                        color: Colors.white,
                                                        size: 30),
                                                    onPressed: () => c.decrement(),
                                                  ),
                                                  const SizedBox(width: 20),
                                                  Obx(() => Text(
                                                    "${c.dish1.toString()}",
                                                    style: const TextStyle(
                                                        color: Colors.white,
                                                        fontSize: 20),
                                                  ),),
                                                  const SizedBox(width: 20),
                                                  IconButton(
                                                    icon: const Icon(Icons.add,
                                                        color: Colors.white,
                                                        size: 30),
                                                    onPressed: () => c.increment(),
                                                  ),
                                                ],
                                              ))),
                                      Text("INR ${c.dish1rs.toDouble()}",
                                          style: TextStyle(fontSize: 15)),
                                    ],
                                  ),
                                ),
                                const SizedBox(height: 20),
                                Padding(
                                  padding:
                                  EdgeInsets.symmetric(horizontal: 32.0),
                                  child: Text("INR ${c.dish1rs.toDouble()}",
                                      style: TextStyle(fontSize: 22)),
                                ),
                                const SizedBox(height: 10),
                                const Padding(
                                  padding:
                                  EdgeInsets.symmetric(horizontal: 32.0),
                                  child: Text("112 calories",
                                      style: TextStyle(fontSize: 22)),
                                ),
                                const SizedBox(height: 30),
                                const Divider(color: Colors.grey),
                              ],
                            )

                          ],
                        ),

                        Padding(
                          padding: const EdgeInsets.all(12.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                "Total Amount",
                                style: TextStyle(
                                    fontSize: 25, fontWeight: FontWeight.bold),
                              ),
                              Obx(() => Text(
                                "INR ${c.total.toDouble()}",
                                style: TextStyle(
                                    fontSize: 25,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.green),
                              ),),
                            ],
                          ),
                        ),
                        const SizedBox(height: 40),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(
                height: 50,
              ),
              SizedBox(
                height: 70,
                width: 400,
                child: ElevatedButton(
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30.0),
                      ),
                    ),
                    backgroundColor:
                    MaterialStateProperty.all(Colors.green.shade900),
                    shadowColor: MaterialStateProperty.all(Colors.transparent),
                  ),
                  child: const Text(
                    'Place Order',
                    style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),
                  ),
                  onPressed: () {
                    Get.snackbar(
                      "Submitted", "Order placed",
                      barBlur: 20,
                      icon: Icon(Icons.add_alert_sharp),
                      isDismissible: true,
                      duration: Duration(seconds: 3),
                      snackPosition: SnackPosition.BOTTOM,
                    );
                    Get.offAll(()=>HomeScreen());
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
