import 'package:dine_with_us/view/view/phone_login/phone_login.dart';
import 'package:dine_with_us/service/firebase_service.dart';
import 'package:dine_with_us/view/home_screeen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';


class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {

  bool isLoading = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
          child: Column(
            children: [
              SafeArea(
                  child: !isLoading? Container(
                    margin: const EdgeInsets.fromLTRB(25, 10, 25, 10),
                    padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                    child: Column(
                      children: [
                        const SizedBox(height: 150.0),
                        Center(
                          child: Image.asset('assets/images/firebase-logo.png',
                              height: 220, width: 220, fit: BoxFit.contain),
                        ),
                        const SizedBox(height: 150),
                        Center(
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(35),
                              child: Container(
                                width: 390,
                                height: 75,
                                decoration:BoxDecoration(
                                  gradient: LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    stops: [0.2, 0.6,1.5],
                                    colors: [
                                      Color(0xff2C6425),
                                      Color(0xff488C34),
                                      Color(0xff61C154)],
                                  ),
                                ),
                                child: ElevatedButton(
                                  onPressed: () async {
                                    setState(() {
                                      isLoading = true;
                                    });
                                    FirebaseService service = FirebaseService();
                                    try {
                                      await service.signInwithGoogle();
                                      Get.off(HomeScreen());
                                    } catch(e){
                                      if(e is FirebaseAuthException){
                                        e.message!;
                                      }
                                    }
                                    setState(() {
                                      isLoading = false;
                                    });
                                  },
                                  // style: ElevatedButton.styleFrom(
                                  //   shape: RoundedRectangleBorder(
                                  //     borderRadius: BorderRadius.circular(55),
                                  //   ),
                                  // ),
                                  child: Row(
                                      children: [
                                        CircleAvatar(
                                          backgroundColor: Colors.white,
                                          child: Image.asset(
                                            'assets/images/google-logo.png',
                                            width: 25,
                                            height: 25,
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                        const SizedBox(width: 80),
                                        const Text(
                                          'Google',
                                          style: TextStyle(
                                            fontSize: 24,
                                            fontFamily: 'Montserrat',
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold,
                                            letterSpacing: 1.25,
                                          ),
                                          textAlign: TextAlign.center,
                                        ),
                                      ]),
                                ),
                              ),
                            )),
                        const SizedBox(height: 20),

                        Center(
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(37),
                              child: Container(
                                width: 390,
                                height: 75,
                                decoration:BoxDecoration(
                                  gradient: LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    stops: [0.2, 0.6,1.5],
                                    colors: [
                                      Color(0xff2C6425),
                                      Color(0xff488C34),
                                      Color(0xff61C154)],
                                  ),
                                ),
                                child: ElevatedButton(
                                    onPressed: () {
                                      Get.to(PhoneAuthPage());
                                    },
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.green,
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(55),
                                      ),
                                    ),
                                    child: Row(
                                      children: const [
                                        Icon(
                                          Icons.phone,
                                          size: 35,
                                        ),
                                        SizedBox(width: 85),
                                        Text(
                                          'Phone',
                                          style: TextStyle(
                                            fontSize: 24,
                                            fontFamily: 'Montserrat',
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold,
                                            letterSpacing: 1.25,
                                          ),
                                          textAlign: TextAlign.center,
                                        ),
                                      ],
                                    )),
                              ),
                            ))
                      ],
                    ),
                  ): Center(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        CircularProgressIndicator(),
                      ],
                    ),
                  ),
              )
            ],
          ),
        ));
  }
}
