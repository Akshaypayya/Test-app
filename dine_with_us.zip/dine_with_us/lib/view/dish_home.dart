import 'package:dine_with_us/controller/data_controller.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';

class SaladsAndSoup extends StatefulWidget {


  @override
  State<SaladsAndSoup> createState() => _SaladsAndSoupState();
}

class _SaladsAndSoupState extends State<SaladsAndSoup> {
  final controller = Get.put(Datacontroller());
  int quantity = 0;

  String? user = FirebaseAuth.instance.currentUser!.email ??
      FirebaseAuth.instance.currentUser!.displayName;

  final FirebaseAuth auth = FirebaseAuth.instance;
  @override
  Widget build(BuildContext context) {
    print("Build created");
    return Scaffold(
      body: SingleChildScrollView(
        child: Obx(() {
          var data = controller.dataModel.value;
          return controller.loading.isTrue
              ? Center(child: CircularProgressIndicator())
              : ListView.builder(
            scrollDirection: Axis.vertical,
            shrinkWrap: true,
            itemCount: data.categoryDishes?.length ?? 0,
            itemBuilder: (context, index) {
              return Column(children: [
                Obx(() => Text(data.categoryDishes![index].dishId.toString())),
                SizedBox(height: 10),
                Obx(()=>Text(data.categoryDishes![index].dishName.toString())),
                SizedBox(height: 10),
                Obx(() => Text(data.categoryDishes![index].dishPrice.toString())),
                SizedBox(height: 10),
                Obx(()=>Text(data.categoryDishes![index].dishImage.toString())),
                SizedBox(height: 10),
                Obx(() =>Text(data.categoryDishes![index].dishCurrency.toString())),
                SizedBox(height: 10),
                Obx(()=>Text(data.categoryDishes![index].dishCalories.toString())),
                SizedBox(height: 10),
                Obx(()=>Text(data.categoryDishes![index].dishDescription.toString())),
                SizedBox(height: 10),
                Obx(()=>Text(data.categoryDishes![index].dishType.toString())),
                SizedBox(height: 10),
                Obx(()=>Text(data.categoryDishes![index].nexturl.toString())),
                SizedBox(height: 10),
                Obx(()=>Text(data.categoryDishes![index].addonCat.toString())),
              ]);
            },
          );
        }),
      ),
    );
  }
}

