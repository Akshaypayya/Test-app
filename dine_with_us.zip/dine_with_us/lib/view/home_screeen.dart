import 'package:dine_with_us/controller/product_controller.dart';
import 'package:dine_with_us/view/view/biriyani.dart';
import 'package:dine_with_us/view/view/fast_food.dart';
import 'package:dine_with_us/view/view/fresh_from_the_sea.dart';
import 'package:dine_with_us/view/view/from_the_barnyard.dart';
import 'package:dine_with_us/view/view/from_the_hen_house.dart';
import 'package:dine_with_us/view/view/salads_and_soups.dart';
import 'package:dine_with_us/service/firebase_service.dart';
import 'package:dine_with_us/view/checkout_screen.dart';
import 'package:dine_with_us/view/login_screen.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
   User? user = FirebaseAuth.instance.currentUser;

  @override
  void initState() {
    super.initState();
  }

  late final _tabController = TabController(length: 6, vsync: this);

   final AddProducts c = Get.put(AddProducts());
  @override
  Widget build(BuildContext context) {
    //final Size size = MediaQuery.of(context).size;
    return DefaultTabController(
        length: 6,
        child: Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            centerTitle: true,
            backgroundColor: Colors.white,
            iconTheme: IconThemeData(color: Colors.grey.shade500, size: 38),
            actions: [
              Container(
                margin: const EdgeInsets.only(
                  top: 16,
                  right: 16,
                ),
                child: Center(
                  child: Stack(
                    children: <Widget>[
                      GestureDetector(
                        onTap: () {
                          Navigator.of(context).push(MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  const CartScreen()));
                        },
                        child: Icon(
                          Icons.shopping_cart_sharp,
                          size: 35,
                          color: Colors.grey.shade500,
                        ),
                      ),
                      Positioned(
                        right: 0,
                        child: Container(
                          padding: const EdgeInsets.all(1),
                          decoration: BoxDecoration(
                            color: Colors.red,
                            borderRadius: BorderRadius.circular(6),
                          ),
                          constraints: const BoxConstraints(
                            minWidth: 15,
                            minHeight: 15,
                          ),
                          child:Obx(() => Text(
                            "${c.total}",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 13,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),),
                        ),
                    ],
                  ),
                ),
              )
            ],
            bottom: TabBar(
                controller: _tabController,
                isScrollable: true,
                physics: const BouncingScrollPhysics(),
                indicatorColor: Colors.red,
                labelColor: Colors.red,
                unselectedLabelColor: Colors.grey.shade500,
                labelPadding: const EdgeInsets.symmetric(horizontal: 10.0),
                tabs: [
                  const Tab(
                    text: "Salads and Soup",
                  ),
                  const Tab(text: "From the barnyard"),
                  const Tab(text: "From the hen house"),
                  const Tab(text: "Fresh from the sea"),
                  const Tab(text: "Biriyani"),
                  const Tab(text: "Fast food"),
                ]),
          ),
          drawer: ClipRRect(
            borderRadius: const BorderRadius.only(
              topRight: Radius.circular(30),
              bottomRight: Radius.circular(30),
            ),
            child: Drawer(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  SizedBox(
                    height: 280,
                    child: ClipRRect(
                      borderRadius: const BorderRadius.only(
                        bottomLeft: Radius.circular(30),
                        bottomRight: Radius.circular(30),
                      ),
                      child: Container(
                        decoration: const BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            stops: [0.2, 0.6, 1.5],
                            colors: [
                              Color(0xff2C6425),
                              Color(0xff488C34),
                              Color(0xff61C154)
                            ],
                          ),
                        ),
                        child: Center(
                          child: Column(
                            children: [
                              const SizedBox(height: 80),
                              CircleAvatar(
                                  radius: 40,
                                  backgroundImage:
                                      NetworkImage(user!.photoURL!)
                              ),
                              SizedBox(height: 10),
                              Text(
                                user!.displayName!,
                                style: const TextStyle(
                                  fontSize: 18,
                                ),
                              ),
                               SizedBox(height: 15),
                              Text(
                                user!.email!,
                                style: const TextStyle(
                                  fontSize: 18,
                                ),
                              ),
                               SizedBox(height: 15),
                              Text(
                                "uid: ${user!.uid}",
                                style: const TextStyle(
                                  fontSize: 15,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Column(
                    children: [
                      const SizedBox(height: 20),
                      ListTile(
                        leading: const Icon(
                          Icons.logout_sharp,
                          color: Colors.grey,
                          size: 40,
                        ),
                        onTap: () async {
                          FirebaseService service = FirebaseService();
                          await service.signOutFromGoogle();
                          Get.offAll(LoginScreen());
                        },
                        title: const Text('    Log out',
                            style: TextStyle(fontSize: 25, color: Colors.grey)),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          // body: TabBarView(
          //     children:[
          body: TabBarView(controller: _tabController, children: [
            SaladsAndSoup(
              onNext: () => _tabController.index = 1,
            ),
            Barnyard(
              onNext: () => _tabController.index = 2,
            ),
            HenHouse(
              onNext: () => _tabController.index = 3,
            ),
            FromSea(
              onNext: () => _tabController.index = 4,
            ),
            Biriyani(
              onNext: () => _tabController.index = 5,
            ),
            FastFood(
              onNext: () => _tabController.index = 6,
            ),
          ]),
        ));
  }
}
