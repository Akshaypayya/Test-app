import 'package:flutter/material.dart';

class FromSea extends StatefulWidget {
  const FromSea({Key? key, required int Function() onNext}) : super(key: key);

  @override
  State<FromSea> createState() => _FromSeaState();
}

class _FromSeaState extends State<FromSea> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          //mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(height: 50),
            Image.asset(
              "assets/images/notfound.png",
              height: 500,
              width: 500,
            ),
            const SizedBox(height: 20),
            Text(
              "Fresh from the sea",
              style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.green.shade900),
            ),
          ],
        ),
      ),
    );
  }
}
