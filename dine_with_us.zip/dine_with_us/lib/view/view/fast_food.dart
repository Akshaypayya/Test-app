import 'package:flutter/material.dart';

class FastFood extends StatelessWidget {
  const FastFood({Key? key, required int Function() onNext}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          //mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(height: 50),
            Image.asset(
              "assets/images/notfound.png",
              height: 500,
              width: 500,
            ),
            const SizedBox(height: 20),
            Text(
              "Fast food",
              style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.green.shade900),
            ),
          ],
        ),
      ),
    );
  }
}
