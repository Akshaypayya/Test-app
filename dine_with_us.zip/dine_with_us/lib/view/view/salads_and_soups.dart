import 'package:dine_with_us/controller/data_controller.dart';
import 'package:dine_with_us/controller/product_controller.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';

class SaladsAndSoup extends StatefulWidget {
  SaladsAndSoup({Key? key, required int Function() onNext}) : super(key: key);

  @override
  State<SaladsAndSoup> createState() => _SaladsAndSoupState();
}

class _SaladsAndSoupState extends State<SaladsAndSoup> {
  int quantity = 1;

  String? user = FirebaseAuth.instance.currentUser!.email ??
      FirebaseAuth.instance.currentUser!.displayName;

  final FirebaseAuth auth = FirebaseAuth.instance;

  final controller = Get.put(Datacontroller());
  final AddProducts c = Get.put(AddProducts());
  int dishType = 1;
  // String? showDishType;


  @override
  Widget build(BuildContext context) {
    print("Build created");
    return SafeArea(
      child: Scaffold(
        body: Container(
          child: Obx(() {
            var data = controller.dataModel.value;
            return controller.loading.isTrue
                ? Center(child: CircularProgressIndicator())
                : ListView.builder(
                    scrollDirection: Axis.vertical,
                    shrinkWrap: true,
                    itemCount: data.categoryDishes?.length ?? 0,
                    itemBuilder: (context, index) {
                      return Column(children: [
                        Padding(
                          padding: const EdgeInsets.all(12.0),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
    //                     SizedBox(
    //                   height: 20, width: 20,
    //                      child:showDishType != null
    //                     ? Image.asset('assets/images/veg.png')
    //                         : Image.asset('assets/images/nonveg.png')
    // ),
                            
                              SizedBox(
                                  height: 20,
                                  child: Text(data.categoryDishes![index].dishType.toString())),
                              Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(children: <Widget>[
                                      SizedBox(
                                        width: 230,
                                        child: Text(
                                          data.categoryDishes![index].dishName.toString(),
                                          maxLines: 2,
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 22),
                                        ),
                                      ),
                                    ]),
                                    SizedBox(height: 10),
                                    Row(
                                      children: [
                                        Text("INR ""${data.categoryDishes![index].dishPrice.toString()}",
                                          style: TextStyle(
                                              fontSize: 18,
                                              fontWeight: FontWeight.bold),
                                        ),
                                        SizedBox(width: 80),
                                        Text(
                                          "${data.categoryDishes![index].dishCalories.toString()} calories",
                                          style: TextStyle(
                                              fontSize: 18,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ],
                                    ),
                                    Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          SizedBox(height: 20),
                                          SizedBox(
                                            width: 260,
                                            child: Text(
                                              data.categoryDishes![index].dishDescription.toString(),
                                              style: TextStyle(
                                                  color: Colors.grey,
                                                  fontSize: 16),
                                            ),
                                          ),
                                          SizedBox(height: 20),
                                          Card(
                                              shape: StadiumBorder(),
                                              color: Colors.green,
                                              child: SizedBox(
                                                  height: 50,
                                                  width: 150,
                                                  child: Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    children: [
                                                      IconButton(
                                                        icon: Icon(Icons.remove,
                                                            color: Colors.white,
                                                            size: 30),
                                                        onPressed: () {
                                                          c.decrement();
                                                        },
                                                      ),
                                                      SizedBox(width: 10),
                                                      Obx(() => Text(
                                                          "${c.dish1.toString()}",
                                                        style: TextStyle(
                                                            color: Colors.white,
                                                            fontSize: 20),
                                                      ),),
                                                      SizedBox(width: 10),
                                                      IconButton(
                                                        icon: Icon(Icons.add,
                                                            color: Colors.white,
                                                            size: 30),
                                                        onPressed: () {
                                                          c.increment();
                                                        },
                                                      ),
                                                    ],
                                                  ))),
                                          SizedBox(height: 10),
                                          Text(
                                            "Customizations Available",
                                            style: TextStyle(
                                                color: Colors.red,
                                                fontSize: 20),
                                          ),
                                          SizedBox(height: 10),
                                        ])
                                  ]),

                              SizedBox(
                                height: 110,
                                width: 110,
                                child:Image.network(data.categoryDishes![index].dishImage.toString(),)                               ),
                            ],
                          ),
                        ),
                        Divider(color: Colors.grey),
                      ]);
                    },
                  );
          }),
        ),
      ),
    );
  }
}
