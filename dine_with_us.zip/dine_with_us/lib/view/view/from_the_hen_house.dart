import 'package:flutter/material.dart';

class HenHouse extends StatefulWidget {
  const HenHouse({Key? key, required int Function() onNext}) : super(key: key);

  @override
  State<HenHouse> createState() => _HenHouseState();
}

class _HenHouseState extends State<HenHouse> {
  int quantity = 0;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: SingleChildScrollView(
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Image.asset('assets/images/veg.png', height: 28, width: 28),
                        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Row(children: const <Widget>[
                            Text(
                              "Spinach Salad",
                              style: TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 22.0),
                            ),
                          ]),
                          const SizedBox(height: 10),
                          Row(
                            children: const [
                              Text(
                                "INR 7.95",
                                style: TextStyle(
                                    fontSize: 22.0, fontWeight: FontWeight.bold),
                              ),
                              SizedBox(width: 50),
                              Text(
                                "15 calories",
                                style: TextStyle(
                                    fontSize: 22.0, fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                          Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 20),
                                const Text(
                                  "Fresh spinach, mushrooms, and hard-\nboiled egg served with warm bacon\nvinaigrette",
                                  style: TextStyle(color: Colors.grey, fontSize: 15),
                                ),
                                const SizedBox(height: 20),
                                Card(
                                    shape: const StadiumBorder(),
                                    color: Colors.green,
                                    child: SizedBox(
                                        height: 50,
                                        width: 150,
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            IconButton(
                                              icon: const Icon(Icons.remove,
                                                  color: Colors.white, size: 30),
                                              onPressed: () {
                                                setState(() {
                                                  quantity--;
                                                });
                                              },
                                            ),
                                            const SizedBox(width: 20),
                                            Text(
                                              quantity.toString(),
                                              style: const TextStyle(
                                                  color: Colors.white, fontSize: 20),
                                            ),
                                            const SizedBox(width: 20),
                                            IconButton(
                                              icon: const Icon(Icons.add,
                                                  color: Colors.white, size: 30),
                                              onPressed: () {
                                                setState(() {
                                                  quantity++;
                                                });
                                              },
                                            ),
                                          ],
                                        ))),
                                const SizedBox(height: 10),
                                const Text(
                                  "Customizations Available",
                                  style: TextStyle(color: Colors.red, fontSize: 20),
                                ),
                                const SizedBox(height: 10),
                              ])
                        ]),
                        Image.asset("assets/images/food.jpg", height: 105, width: 105),
                      ],
                    ),
                  ),
                  const Divider(color: Colors.grey),
                  Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Image.asset('assets/images/nonveg.png', height: 28, width: 28),
                        Expanded(
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(children: const <Widget>[
                                  Text(
                                    "Traditional New England \nSeafood Chowder",
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold, fontSize: 22.0),
                                  ),
                                ]),
                                const SizedBox(height: 10),
                                Row(
                                  children: const [
                                    Text(
                                      "INR 12.00",
                                      style: TextStyle(
                                          fontSize: 22.0, fontWeight: FontWeight.bold),
                                    ),
                                    SizedBox(width: 45),
                                    Text(
                                      "30 calories",
                                      style: TextStyle(
                                          fontSize: 22.0, fontWeight: FontWeight.bold),
                                    ),
                                  ],
                                ),
                                Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const SizedBox(height: 20),
                                      const Text(
                                        "With clams, scallops and shrimp",
                                        style:
                                        TextStyle(color: Colors.grey, fontSize: 15),
                                      ),
                                      const SizedBox(height: 20),
                                      Card(
                                          shape: const StadiumBorder(),
                                          color: Colors.green,
                                          child: SizedBox(
                                              height: 50,
                                              width: 150,
                                              child: Row(
                                                mainAxisAlignment:
                                                MainAxisAlignment.center,
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  IconButton(
                                                    icon: const Icon(Icons.remove,
                                                        color: Colors.white, size: 30),
                                                    onPressed: () {
                                                      setState(() {
                                                        quantity--;
                                                      });
                                                    },
                                                  ),
                                                  const SizedBox(width: 20),
                                                  Text(
                                                    quantity.toString(),
                                                    style: const TextStyle(
                                                        color: Colors.white,
                                                        fontSize: 20),
                                                  ),
                                                  const SizedBox(width: 20),
                                                  IconButton(
                                                    icon: const Icon(Icons.add,
                                                        color: Colors.white, size: 30),
                                                    onPressed: () {
                                                      setState(() {
                                                        quantity++;
                                                      });
                                                    },
                                                  ),
                                                ],
                                              ))),
                                      const SizedBox(height: 10),
                                      // Text(
                                      //   "Customizations Available",
                                      //   style: TextStyle(
                                      //       color: Colors.red, fontSize: 20),
                                      // ),
                                      // SizedBox(height: 10),
                                    ])
                              ]),
                        ),
                        Image.asset("assets/images/food.jpg", height: 105, width: 105),
                      ],
                    ),
                  ),
                  const Divider(color: Colors.grey),
                  Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Image.asset('assets/images/veg.png', height: 28, width: 28),
                        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Row(children: const <Widget>[
                            Text(
                              "Salad Bar Soup",
                              style: TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 22.0),
                            ),
                          ]),
                          const SizedBox(height: 10),
                          Row(
                            children: const [
                              Text(
                                "INR 5.00",
                                style: TextStyle(
                                    fontSize: 22.0, fontWeight: FontWeight.bold),
                              ),
                              SizedBox(width: 50),
                              Text(
                                "30 calories",
                                style: TextStyle(
                                    fontSize: 22.0, fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                          Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 20),
                                const Text(
                                  "Flour Mixed with fresh green leafy\nvegetables",
                                  style: TextStyle(color: Colors.grey, fontSize: 15),
                                ),
                                const SizedBox(height: 20),
                                Card(
                                    shape: const StadiumBorder(),
                                    color: Colors.green,
                                    child: SizedBox(
                                        height: 50,
                                        width: 150,
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            IconButton(
                                              icon: const Icon(Icons.remove,
                                                  color: Colors.white, size: 30),
                                              onPressed: () {
                                                setState(() {
                                                  quantity--;
                                                });
                                              },
                                            ),
                                            const SizedBox(width: 20),
                                            Text(
                                              quantity.toString(),
                                              style: const TextStyle(
                                                  color: Colors.white, fontSize: 20),
                                            ),
                                            const SizedBox(width: 20),
                                            IconButton(
                                              icon: const Icon(Icons.add,
                                                  color: Colors.white, size: 30),
                                              onPressed: () {
                                                setState(() {
                                                  quantity++;
                                                });
                                              },
                                            ),
                                          ],
                                        ))),
                                const SizedBox(height: 10),
                                // Text(
                                //   "Customizations Available",
                                //   style: TextStyle(
                                //       color: Colors.red, fontSize: 20),
                                // ),
                                // SizedBox(height: 10),
                              ])
                        ]),
                        Image.asset("assets/images/food.jpg", height: 105, width: 105),
                      ],
                    ),
                  ),
                  const Divider(color: Colors.grey),
                  Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Image.asset('assets/images/nonveg.png', height: 28, width: 28),
                        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Row(children: const <Widget>[
                            Text(
                              "Chicken-soup",
                              style: TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 22.0),
                            ),
                          ]),
                          const SizedBox(height: 10),
                          Row(
                            children: const [
                              Text(
                                "INR 14.89",
                                style: TextStyle(
                                    fontSize: 22.0, fontWeight: FontWeight.bold),
                              ),
                              SizedBox(width: 45),
                              Text(
                                "30 calories",
                                style: TextStyle(
                                    fontSize: 22.0, fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                          Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 20),
                                const Text(
                                  "Fresh as home-made chicken-soup",
                                  style: TextStyle(color: Colors.grey, fontSize: 15),
                                ),
                                const SizedBox(height: 20),
                                Card(
                                    shape: const StadiumBorder(),
                                    color: Colors.green,
                                    child: SizedBox(
                                        height: 50,
                                        width: 150,
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            IconButton(
                                              icon: const Icon(Icons.remove,
                                                  color: Colors.white, size: 30),
                                              onPressed: () {
                                                setState(() {
                                                  quantity--;
                                                });
                                              },
                                            ),
                                            const SizedBox(width: 20),
                                            Text(
                                              quantity.toString(),
                                              style: const TextStyle(
                                                  color: Colors.white, fontSize: 20),
                                            ),
                                            const SizedBox(width: 20),
                                            IconButton(
                                              icon: const Icon(Icons.add,
                                                  color: Colors.white, size: 30),
                                              onPressed: () {
                                                setState(() {
                                                  quantity++;
                                                });
                                              },
                                            ),
                                          ],
                                        ))),
                                const SizedBox(height: 10),
                                // Text(
                                //   "Customizations Available",
                                //   style: TextStyle(
                                //       color: Colors.red, fontSize: 20),
                                // ),
                                //SizedBox(height: 10),
                              ])
                        ]),
                        Expanded(
                          child: Image.asset("assets/images/food.jpg",
                              height: 105, width: 105),
                        ),
                      ],
                    ),
                  ),
                  const Divider(color: Colors.grey),
                ],
              ),
            )));
  }
}
