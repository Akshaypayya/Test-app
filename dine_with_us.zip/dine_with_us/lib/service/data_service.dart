import 'dart:convert';

import 'package:dine_with_us/model/TestData.dart';
import 'package:http/http.dart' as http;

class DataService {
  var url = "https://www.mocky.io/v2/5dfccffc310000efc8d2c1ad";
  Future<TestData?> getService() async {
    print("object");
    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        var body = await json.decode(response.body);
        // var body = await json.decode(response.body.toString());
        // Iterable list = body[0]['table_menu_list'][0]['category_dishes'];
        // return list.map((e) => TableMenuList.fromJson(e)).toList();
        var model = TestData.fromJson(body[0]);
        return TestData.fromJson(body[0]);
        // return TableMenuList.fromJson(jsonDecode(response.body)[0]);
      }
    } catch (Exception) {
      print(Exception);
      print("Error occured");
    }
  }
}
