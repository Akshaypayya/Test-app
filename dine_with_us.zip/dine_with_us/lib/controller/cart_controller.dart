import 'package:dine_with_us/model/cart_item.dart';
import 'package:get/get.dart';
import 'package:flutter/material.dart';
import '../view/checkout_screen.dart';

class ProductController extends GetxController {

  Map<int, CartItem> _items = {};

  Map<int, CartItem> get items {
    return {..._items};
  }

  int get itemCount{
    // return  _items?.length?? 0;
    return _items.length;

  }
  double get totalAmount{
    var total = 0.0;
    _items.forEach((key, cartItem) {
      total += cartItem.dishPrice * cartItem.quantity;
    });
    return total;
  }


  void removeitem(int productId){
    _items.remove(productId);
    update();
  }

  void clear(){
    _items = {};
    update();
  }

}
  //
  // Widget navigateToCartScreen(BuildContext context) {
  //   isCartScreen = true;
  //   isItemListScreen = false;
  //  totalPrice();
  //   return CartScreen();
  // }
  //
  // countAllItems() {
  //   itemCount.value = 0;
  //   for (var element in allProducts) {
  //     itemCount.value += element.count;
  //   }
  // }
  //
  // totalPrice() {
  //   price.value = 0.0;
  //   for (var element in allProducts) {
  //     if (element.count > 0) {
  //       price.value = (double.parse(element.price.replaceAll().trim()) * element.count) +
  //           price.value;
  //     }
  //   }
  // }
  //
  // void increase(int index) {
  //   allProducts[index].count++;
  //   allProducts.refresh();
  //   countAllItems();
  //   totalPrice();
  // }
  //
  // void decrease(int index) {
  //   if (allProducts[index].count > 0) {
  //     allProducts[index].count--;
  //     allProducts.refresh();
  //     countAllItems();
  //     totalPrice();
  //   }
  // }
  //
  // void removeItems(){
  //   for(var item in allProducts)
  //     item.count = 0;
  //   allProducts.refresh();
  //   itemCount.value = 0;
  //   totalPrice();
  // }
  //
  //
  // VoidCallback? isCheckOutButtonEnabled(){
  //   if(itemCount>0) return (){};
  //   return null;
  // }
