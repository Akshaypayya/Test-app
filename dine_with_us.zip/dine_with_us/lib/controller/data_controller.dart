import 'package:dine_with_us/service/data_service.dart';
import 'package:get/get.dart';
import '../model/TestData.dart';

class Datacontroller extends GetxController {
  var dataModel = TableMenuList().obs;
  var loading = true.obs;

  getData() async {
    print("GetDAta");
    try {
      loading.value = true;
      var data = await DataService().getService();
      if (data != null) {
        print(data);
        dataModel.value = data.tableMenuList![0];
        loading.value = false;
      }
    } catch (e) {
      Get.snackbar(
        "title",
        "$e",
        duration: const Duration(seconds: 5),
        snackPosition: SnackPosition.BOTTOM,
      );

      loading.value = false;
    }
  }

  @override
  void onInit() {
    print("on init");
    getData();
    super.onInit();
  }
}
