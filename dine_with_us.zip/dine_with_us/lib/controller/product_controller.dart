import 'package:dine_with_us/model/product.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../model/datamodel.dart';


class AddProducts extends GetxController {

  var dish1 = 0.obs;
  var dish2 = 0.obs;
  var dish1rs =20.obs;
  var dish2rs =45.obs;


  int get total => (dish1.value + dish2.value);

  increment() => dish1.value++;
  decrement() {
    if (dish1.value <= 0) {
      Get.snackbar(
          "Selecting Dish", " cannot be less than zero",
          barBlur: 20,
          icon: Icon(Icons.add_alert_sharp),
          isDismissible: true,
          duration: Duration(seconds: 3),
        snackPosition: SnackPosition.BOTTOM,
      );
    } else {
      dish1.value--;
    }
  }

  increment2() => dish2.value++;
  decrement2() {
    if (dish2.value <= 0) {
      Get.snackbar(
        "Selecting Dish", " cannot be less than zero",
        barBlur: 20,
        icon: Icon(Icons.add_alert_sharp),
        isDismissible: true,
        duration: Duration(seconds: 3),
        snackPosition: SnackPosition.BOTTOM,
      );
    } else {
      dish2.value--;
    }
  }
  List<Product> _items = [
    Product(
      dishId:  "100000001",
      dishName: "Spinach Salad",
      dishPrice: 7.95,
      dishImage: "http://restaurants.unicomerp.net//images/Restaurant/1010000001/Item/Items/100000001.jpg",
      dishCurrency: "INR",
      dishCalories: 15.0,
      dishDescription: "Fresh spinach, mushrooms, and hard-boiled egg served with warm bacon vinaigrette",
      dishAvailability: true,
      dishType:  2,
      nexturl: "http://snapittapp.snapitt.net/api/menu/30/?org=1010000001&branch_id=1000000001&menuItem=100000001&limit=10&offset=20&lang=en",
      quantity: 0,
    ),
    Product(
      dishId:  "100000003",
      dishName: "Traditional New England Seafood Chowder",
      dishPrice: 12.0,
      dishImage:  "http://restaurants.unicomerp.net/images/Restaurant/1010000001/Item/Items/100000003.jpg",
      dishCurrency: "INR",
      dishCalories: 30.0,
      dishDescription: "with clams, scallops, and shrimp,",
      dishAvailability:true,
      dishType: 1,
      nexturl: "http://snapittapp.snapitt.net/api/menu/30/?org=1010000001&branch_id=1000000001&menuItem=100000003&limit=10&offset=20&lang=en",
      quantity: 0,
    ),
    Product(
      dishId:  "100000004",
      dishName: "Salad Bar Soup",
      dishPrice:5.0,
      dishImage: "http://restaurants.unicomerp.net/images/Restaurant/1010000001/Item/Items/100000004.jpg",
      dishCurrency:  "INR",
      dishCalories: 30.0,
      dishDescription:  "Flour Mixed with fresh green leafy vegetables",
      dishAvailability: true,
      dishType: 2,
      nexturl:  "http://snapittapp.snapitt.net/api/menu/30/?org=1010000001&branch_id=1000000001&menuItem=100000004&limit=10&offset=20&lang=en",
      quantity: 0,
    ),
    Product(
      dishId: "100000005",
      dishName: "chicken-soup",
      dishPrice: 14.89,
      dishImage:  "http://restaurants.unicomerp.net/images/Restaurant/1010000001/Item/Items/100000005.jpg",
      dishCurrency: "INR",
      dishCalories: 30.0,
      dishDescription:  "fresh as home-made chicken-soup",
      dishAvailability: false,
      dishType: 1,
      nexturl: "http://snapittapp.snapitt.net/api/menu/30/?org=1010000001&branch_id=1000000001&menuItem=100000005&limit=10&offset=20&lang=en",
      quantity:0,
    ),
    Product(
      dishId:  "100000006",
      dishName: "One-Pot-Vegetarian",
      dishPrice: 22.0,
      dishImage:  "http://restaurants.unicomerp.net/images/Restaurant/1010000001/Item/Items/100000006.jpg",
      dishCurrency: "INR",
      dishCalories: 25.0,
      dishDescription:"One-Pot-Vegetarian-Orzo-Vegetable-Soup",
      dishAvailability: false,
      dishType:1,
      nexturl: "http://snapittapp.snapitt.net/api/menu/30/?org=1010000001&branch_id=1000000001&menuItem=100000006&limit=10&offset=20&lang=en",
      quantity: 0,
    ),
    Product(
      dishId:   "100000007",
      dishName: "low-carb-chicken-soup",
      dishPrice: 25.0,
      dishImage: "http://restaurants.unicomerp.net/images/Restaurant/1010000001/Item/Items/100000007.jpg",
      dishCurrency: "INR",
      dishCalories: 25.0,
      dishDescription: "wholesomeyum_low-carb-chicken-soup-with-spaghetti-squash-paleo-gluten-free.jpg",
      dishAvailability: false,
      dishType:1,
      nexturl: "http://snapittapp.snapitt.net/api/menu/30/?org=1010000001&branch_id=1000000001&menuItem=100000007&limit=10&offset=20&lang=en",
      quantity: 0,
    ),
  ];

  List<Product> get items{
    return [..._items];
  }


  Product findProductById(int dishId){
    return _items.firstWhere((element) => element.dishId == dishId);
  }
  void addProduct(){
    update();
  }

}