class CartItem {
  final String dishId;
  final String dishName;
  final int quantity;
  final double dishPrice;
  final String dishCurrency;
  final double dishCalories;

  CartItem(
      { required this.dishId,
        required this.dishName,
        required this.quantity,
        required this.dishCurrency,
        required this.dishCalories,
        required this.dishPrice});
}
