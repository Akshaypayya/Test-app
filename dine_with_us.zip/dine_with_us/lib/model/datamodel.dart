// To parse this JSON data, do
//
//     final datamodel = datamodelFromJson(jsonString);
//
//
// import 'dart:convert';
//
// // List<CategoryDishes> datamodelFromJson(String str) => List<CategoryDishes>.from(json.decode(str).map((e) => CategoryDishes.fromJson(e)));
// //
// // List datamodelToJson(List<TableMenuList> data) => List<CategoryDishes>.from(data.map((e) => e.toJson()));
//
class DataModel {
  String? restaurantId;
  String? restaurantName;
  String? restaurantImage;
  String? tableId;
  String? tableName;
  String? branchName;
  String? nexturl;
  List<TableMenuList>? tableMenuList;

  DataModel(
      {this.restaurantId,
      this.restaurantName,
      this.restaurantImage,
      this.tableId,
      this.tableName,
      this.branchName,
      this.nexturl,
      this.tableMenuList});

  DataModel.fromJson(Map<String, dynamic> json) {
    restaurantId = json['restaurant_id'];
    restaurantName = json['restaurant_name'];
    restaurantImage = json['restaurant_image'];
    tableId = json['table_id'];
    tableName = json['table_name'];
    branchName = json['branch_name'];
    nexturl = json['nexturl'];
    if (json['table_menu_list'] != null) {
      tableMenuList = <TableMenuList>[];
      json['table_menu_list'].forEach((v) {
        tableMenuList!.add(TableMenuList.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> tableMenuList = Map<String, dynamic>();
    tableMenuList['restaurant_id'] = this.restaurantId;
    tableMenuList['restaurant_name'] = this.restaurantName;
    tableMenuList['restaurant_image'] = this.restaurantImage;
    tableMenuList['table_id'] = this.tableId;
    tableMenuList['table_name'] = this.tableName;
    tableMenuList['branch_name'] = this.branchName;
    tableMenuList['nexturl'] = this.nexturl;
    if (this.tableMenuList != null) {
      tableMenuList['table_menu_list'] = this.tableMenuList!.map((v) => v.toJson()).toList();
    }
    return tableMenuList;
  }
}

class TableMenuList {
  String? menuCategory;
  String? menuCategoryId;
  String? menuCategoryImage;
  String? nexturl;
  List<CategoryDishes>? categoryDishes;

  TableMenuList(
      {this.menuCategory,
      this.menuCategoryId,
      this.menuCategoryImage,
      this.nexturl,
      this.categoryDishes});

  TableMenuList.fromJson(Map<String, dynamic> json) {
    menuCategory = json['menu_category'];
    menuCategoryId = json['menu_category_id'];
    menuCategoryImage = json['menu_category_image'];
    nexturl = json['nexturl'];
    if (json['category_dishes'] != null) {
      categoryDishes = <CategoryDishes>[];
      json['category_dishes'].forEach((v) {
        categoryDishes!.add(CategoryDishes.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> categoryDishes = Map<String, dynamic>();
    categoryDishes['menu_category'] = this.menuCategory;
    categoryDishes['menu_category_id'] = this.menuCategoryId;
    categoryDishes['menu_category_image'] = this.menuCategoryImage;
    categoryDishes['nexturl'] = this.nexturl;
    if (this.categoryDishes != null) {
      categoryDishes['category_dishes'] = this.categoryDishes!.map((v) => v.toJson()).toList();
    }
    return categoryDishes;
  }
}

class CategoryDishes {
  String? dishId;
  String? dishName;
  dynamic dishPrice;
  String? dishImage;
  String? dishCurrency;
  int? dishCalories;
  String? dishDescription;
  bool? dishAvailability;
  int? dishType;
  String? nexturl;
  List<AddonCat>? addonCat;

  CategoryDishes(
      {this.dishId,
      this.dishName,
      this.dishPrice,
      this.dishImage,
      this.dishCurrency,
      this.dishCalories,
      this.dishDescription,
      this.dishAvailability,
      this.dishType,
      this.nexturl,
      this.addonCat});

  CategoryDishes.fromJson(Map<String, dynamic> json) {
    dishId = json['dish_id'];
    dishName = json['dish_name'];
    dishPrice = json['dish_price'];
    dishImage = json['dish_image'];
    dishCurrency = json['dish_currency'];
    dishCalories = json['dish_calories'];
    dishDescription = json['dish_description'];
    dishAvailability = json['dish_Availability'];
    dishType = json['dish_Type'];
    nexturl = json['nexturl'];
    if (json['addonCat'] != null) {
      addonCat = <AddonCat>[];
      json['addonCat'].forEach((v) {
        addonCat!.add(AddonCat.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> addonCat = Map<String, dynamic>();
    addonCat['dish_id'] = this.dishId;
    addonCat['dish_name'] = this.dishName;
    addonCat['dish_price'] = this.dishPrice;
    addonCat['dish_image'] = this.dishImage;
    addonCat['dish_currency'] = this.dishCurrency;
    addonCat['dish_calories'] = this.dishCalories;
    addonCat['dish_description'] = this.dishDescription;
    addonCat['dish_Availability'] = this.dishAvailability;
    addonCat['dish_Type'] = this.dishType;
    addonCat['nexturl'] = this.nexturl;
    if (this.addonCat != null) {
      addonCat['addonCat'] = this.addonCat!.map((v) => v.toJson()).toList();
    }
    return addonCat;
  }
}

class AddonCat {
  String? addonCategory;
  String? addonCategoryId;
  int? addonSelection;
  String? nexturl;
  List<Addons>? addons;

  AddonCat(
      {this.addonCategory,
      this.addonCategoryId,
      this.addonSelection,
      this.nexturl,
      this.addons});

  AddonCat.fromJson(Map<String, dynamic> json) {
    addonCategory = json['addon_category'];
    addonCategoryId = json['addon_category_id'];
    addonSelection = json['addon_selection'];
    nexturl = json['nexturl'];
    if (json['addons'] != null) {
      addons = <Addons>[];
      json['addons'].forEach((v) {
        addons!.add(Addons.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> addons = Map<String, dynamic>();
    addons['addon_category'] = this.addonCategory;
    addons['addon_category_id'] = this.addonCategoryId;
    addons['addon_selection'] = this.addonSelection;
    addons['nexturl'] = this.nexturl;
    if (this.addons != null) {
      addons['addons'] = this.addons!.map((v) => v.toJson()).toList();
    }
    return addons;
  }
}

class Addons {
  String? dishId;
  String? dishName;
  int? dishPrice;
  String? dishImage;
  String? dishCurrency;
  int? dishCalories;
  String? dishDescription;
  bool? dishAvailability;
  int? dishType;

  Addons(
      {this.dishId,
      this.dishName,
      this.dishPrice,
      this.dishImage,
      this.dishCurrency,
      this.dishCalories,
      this.dishDescription,
      this.dishAvailability,
      this.dishType});

  Addons.fromJson(Map<String, dynamic> json) {
    dishId = json['dish_id'];
    dishName = json['dish_name'];
    dishPrice = json['dish_price'];
    dishImage = json['dish_image'];
    dishCurrency = json['dish_currency'];
    dishCalories = json['dish_calories'];
    dishDescription = json['dish_description'];
    dishAvailability = json['dish_Availability'];
    dishType = json['dish_Type'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> addonss =Map<String, dynamic>();
    addonss['dish_id'] = this.dishId;
    addonss['dish_name'] = this.dishName;
    addonss['dish_price'] = this.dishPrice;
    addonss['dish_image'] = this.dishImage;
    addonss['dish_currency'] = this.dishCurrency;
    addonss['dish_calories'] = this.dishCalories;
    addonss['dish_description'] = this.dishDescription;
    addonss['dish_Availability'] = this.dishAvailability;
    addonss['dish_Type'] = this.dishType;
    return addonss;
  }
}

//
//
//
//
//
//


//
//
// import 'dart:convert';
//
// TableMenuList dataModelFromJson(String str) =>TableMenuList.fromJson(json.decode(str));
//
// String dataModelToJson(TableMenuList data) => json.encode(data.toJson());
//
//

// import 'dart:convert';
//
// TableMenuList dataModelFromJson(String str) =>TableMenuList.fromJson(json.decode(str));
//
// String dataModelToJson(TableMenuList data) => json.encode(data.toJson());

//
// class DataModel {
//   int? restaurantId;
//   String? restaurantName;
//   String? restaurantImage;
//   int? tableId;
//   String? tableName;
//   String? branchName;
//   String? nexturl;
//   List<TableMenuList>? tableMenuList;
//
//   DataModel({
//     this.restaurantId,
//     this.restaurantName,
//     this.restaurantImage,
//     this.tableId,
//     this.tableName,
//     this.branchName,
//     this.nexturl,
//     this.tableMenuList,
//   });
//
//   DataModel.fromJson(Map<String, dynamic> json) {
//       restaurantId= json["restaurant_id"];
//       restaurantName= json["restaurant_name"];
//       restaurantImage= json["restaurant_image"];
//       tableId= json["table_id"];
//       tableName= json["table_name"];
//       branchName= json["branch_name"];
//       nexturl= json["nexturl"];
//     if (json['data'] != null) {
//     tableMenuList = <TableMenuList>[];
//     json['data'].forEach((v) {
//       tableMenuList!.add(TableMenuList.fromJson(v));
//     });
//     }
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String,dynamic> tableMenuList = Map<String,dynamic>();
//     tableMenuList["restaurant_id"] = this.restaurantId;
//     tableMenuList["restaurant_name"] = this.restaurantName;
//     tableMenuList["restaurant_image"] = this.restaurantImage;
//     tableMenuList["table_id"] = this.tableId;
//     tableMenuList["table_name"] = this.tableName;
//     tableMenuList["branch_name"] = this.branchName;
//     tableMenuList["nexturl"] = this.nexturl;
//     if (this.tableMenuList != null) {
//     tableMenuList['data'] = this.tableMenuList!.map((v) => v.toJson()).toList();
//     }
//     return tableMenuList;
//   }
// }
//
// class TableMenuList {
//   String? menuCategory;
//   int? menuCategoryId;
//   String? menuCategoryImage;
//   String? nexturl;
//   List<CategoryDishes>? categoryDishes;
//
//   TableMenuList({
//     this.menuCategory,
//     this.menuCategoryId,
//     this.menuCategoryImage,
//     this.nexturl,
//     this.categoryDishes,
//   });
//
//
//   TableMenuList.fromJson(Map<String, dynamic> json){
//     menuCategory = json["menu_category"];
//     menuCategoryId= json["menu_category_id"];
//     menuCategoryImage= json["menu_category_image"];
//     nexturl= json["nexturl"];
//     if (json['data'] != null) {
//       categoryDishes = <CategoryDishes>[];
//       json['data'].forEach((v) {
//         categoryDishes!.add(CategoryDishes.fromJson(v));
//       });
//     }
//   }
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = Map<String, dynamic>();
//     "menu_category": menuCategory,
//     "menu_category_id": menuCategoryId,
//     "menu_category_image": menuCategoryImage,
//     "nexturl": nexturl,
//     "category_dishes": List<dynamic>.from(
//         categoryDishes!.map((e) => e.toJson())).toList(),
//   };
// }
//
// class CategoryDishes {
//   int? dishId;
//   String? dishName;
//   double? dishPrice;
//   String? dishImage;
//   String? dishCurrency;
//   double? dishCalories;
//   String? dishDescription;
//   dynamic dishAvailability;
//   int? dishType;
//   dynamic nexturl;
//   List<AddonCat>? addonCat;
//
//   CategoryDishes({
//     this.dishId,
//     this.dishName,
//     this.dishPrice,
//     this.dishImage,
//     this.dishCurrency,
//     this.dishCalories,
//     this.dishDescription,
//     this.dishAvailability,
//     this.dishType,
//     this.nexturl,
//     this.addonCat,
//   });
//
//   factory CategoryDishes.fromJson(Map<String, dynamic> json) => CategoryDishes(
//     dishId: json["dish_id"],
//     dishName: json["dish_name"],
//     dishPrice: json["dish_price"].toDouble(),
//     dishImage: json["dish_image"],
//     dishCurrency: json["dish_currency"],
//     dishCalories: json["dish_calories"].toDouble(),
//     dishDescription: json["dish_description"],
//     dishAvailability: json["dish_Availability"],
//     dishType: json["dish_Type"],
//     nexturl: json["nexturl"],
// //        addonCat: List<AddonCat>.from(json["addonCat"].map((e) => AddonCat.fromJson(e))),
//     // addonCat: json["addonCat"] != null ? List<AddonCat>.from( json["addonCat"].map((e) => AddonCat.fromJson(e))) : <AddonCat>[],
//     addonCat:List<AddonCat>.from(json["addonCat"].map((e) => AddonCat.fromJson(e))),
//   );
//
//   Map<String, dynamic> toJson() => {
//     "dish_id": dishId,
//     "dish_name": dishName,
//     "dish_price": dishPrice,
//     "dish_image": dishImage,
//     "dish_currency": dishCurrency,
//     "dish_calories": dishCalories,
//     "dish_description": dishDescription,
//     "dish_Availability": dishAvailability,
//     "dish_Type": dishType,
//     "nexturl": nexturl,
//     "addonCat":
//     List<dynamic>.from(addonCat!.map((e) => e.toJson()).toList()),
//   };
// }
//
// class AddonCat {
//   String? addonCategory;
//   int? addonCategoryId;
//   int? addonSelection;
//   String? nexturl;
//   List<Addons>? addons;
//
//   AddonCat({
//     this.addonCategory,
//     this.addonCategoryId,
//     this.addonSelection,
//     this.nexturl,
//     this.addons,
//   });
//
//   factory AddonCat.fromJson(Map<String, dynamic> json) => AddonCat(
//     addonCategory: json["addon_category"],
//     addonCategoryId: json["addon_category_id"],
//     addonSelection: json["addon_selection"],
//     nexturl: json["nexturl"],
//     //addons: List<Addons>.from(json["addons"].map((e) => Addons.fromJson(e))),
//     //addons: json["addons"] != null ? List<Addons>.from( json["addons"].map((e) => Addons.fromJson(e))) : <Addons>[],
//     addons:List<Addons>.from(json["addons"].map((e) => Addons.fromJson(e))),
//   );
//
//   Map<String, dynamic> toJson() => {
//     "addon_category": addonCategory,
//     "addon_category_id": addonCategoryId,
//     "addon_selection": addonSelection,
//     "nexturl": nexturl,
//     "addons": List<dynamic>.from(addons!.map((e) => e.toJson()).toList()),
//   };
// }
//
// class Addons {
//   int? dishId;
//   String? dishName;
//   double? dishPrice;
//   String? dishImage;
//   String? dishCurrency;
//   double? dishCalories;
//   String? dishDescription;
//   bool? dishAvailability;
//   int? dishType;
//
//   Addons({
//     this.dishId,
//     this.dishName,
//     this.dishPrice,
//     this.dishImage,
//     this.dishCurrency,
//     this.dishCalories,
//     this.dishDescription,
//     this.dishAvailability,
//     this.dishType,
//   });
//
//   factory Addons.fromJson(Map<String, dynamic> json) => Addons(
//     dishId: json["dish_id"],
//     dishName: json["dish_name"],
//     dishPrice: json["dish_price"].toDouble(),
//     dishImage: json["dish_image"],
//     dishCurrency: json["dish_currency"],
//     dishCalories: json["dish_calories"].toDouble(),
//     dishDescription: json["dish_description"],
//     dishAvailability: json["dish_Availability"],
//     dishType: json["dish_Type"],
//   );
//
//   Map<String, dynamic> toJson() => {
//     "dish_id": dishId,
//     "dish_name": dishName,
//     "dish_price": dishPrice,
//     "dish_image": dishImage,
//     "dish_currency": dishCurrency,
//     "dish_calories": dishCalories,
//     "dish_description": dishDescription,
//     "dish_Availability": dishAvailability,
//     "dish_Type": dishType,
//   };
// }