package com.dinewithus.dine_with_us

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
